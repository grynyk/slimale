import { test, expect, Locator } from '@playwright/test';
import { MealsTab } from '../../pages/meals-page/tabs/meals-tab';
import { CartTab } from '../../pages/meals-page/tabs/cart-tab';
import { MealsPage } from '../../pages/meals-page/meals-page';

test.describe.configure({ mode: 'serial' });
test.use({ contextOptions: { reducedMotion: 'reduce' } });

test.describe('Cart tab tests', () => {
  let mealsPage: MealsPage;
  let mealsTab: MealsTab
  let cartTab: CartTab;

  test.beforeEach(async ({ page }) => {
    mealsPage = new MealsPage(page);
    mealsTab = new MealsTab(page);
    cartTab = new CartTab(page);
    await mealsPage.loadApp();
    await mealsPage.goTo();
  });

  test('remove all meals from cart tab', async ({page}) => {
    await mealsPage.mealsTab.click();
    await mealsTab.clickAddToBasketByIndex([0, 11, 21, 31, 41]);
    await mealsPage.cartTab.click();
    await page.waitForTimeout(1000);
    await expect(cartTab.getMealCount()).resolves.toBe(5);
    await cartTab.removeAllItemsFromCart();
    await expect(cartTab.emptyCartText).toBeVisible();
    await expect(cartTab.visitMealsTabButton).toBeVisible();

  });

  test('remove specific meal from cart tab', async ({page}) => {
    await mealsPage.mealsTab.click();
    await mealsTab.clickAddToBasketByIndex([2]);
    await mealsPage.cartTab.click();
    await page.waitForTimeout(1200);
    await expect(cartTab.getMealCount()).resolves.toBe(1);
    await cartTab.removeSpecificItemFromCart(0);
    await expect(cartTab.emptyCartText).toBeVisible();
    await expect(cartTab.visitMealsTabButton).toBeVisible();
  });

  test('Send meals ingredience to user email', async ({page}) => {
    await mealsPage.mealsTab.click();
    await mealsTab.clickAddToBasketByIndex([2]);
    await mealsPage.cartTab.click();
    await page.waitForTimeout(1200);
    await cartTab.showIngredientsButton.click();
    const ingredientsTitle = page.locator('p:has-text("Seznam ingrediencií")');
    await expect(ingredientsTitle).toBeVisible();
    await cartTab.sendEmailButton.click();
    await expect(cartTab.toastConfirmationMessage).toBeVisible();
  });

  test('Add and remove custom meals ingredinece', async ({page}) => {
    await mealsPage.mealsTab.click();
    await mealsTab.clickAddToBasketByIndex([2]);
    await mealsPage.cartTab.click();
    await page.waitForTimeout(1200);
    await cartTab.showIngredientsButton.click();
    await cartTab.addCustomIngredient('Cibule');
    await cartTab.removeCustomIngredient();
    await expect(cartTab.removeIngredientButton).not.toBeVisible();
  });
  

});