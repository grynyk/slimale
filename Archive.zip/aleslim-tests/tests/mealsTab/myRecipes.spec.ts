import { test, expect, Locator } from '@playwright/test';
import { MealsTab } from '../../pages/meals-page/tabs/meals-tab';
import { CartTab } from '../../pages/meals-page/tabs/cart-tab';
import { MealsPage } from '../../pages/meals-page/meals-page';

test.describe('My recipes Tests', () => {
  let mealsPage: MealsPage;
  let mealsTab: MealsTab
  let cartTab: CartTab;

  test.beforeEach(async ({ page }) => {
    mealsPage = new MealsPage(page);
    mealsTab = new MealsTab(page);
    cartTab = new CartTab(page);
    await mealsPage.loadApp();
    await mealsPage.goTo();
  });

});