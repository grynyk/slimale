import { test, expect, Locator } from '@playwright/test';
import { MealsTab } from '../../pages/meals-page/tabs/meals-tab';
import { MealsPage } from '../../pages/meals-page/meals-page';
import { PreferenceTab } from '../../pages/meals-page/tabs/preference-tab';

test.describe('Performance tab tests', () => {
  let mealsPage: MealsPage;
  let mealsTab: MealsTab;
  let preferencesTab: PreferenceTab;

  test.beforeEach(async ({ page }) => {
    mealsPage = new MealsPage(page);
    mealsTab = new MealsTab(page);
    preferencesTab = new PreferenceTab(page);
    await mealsPage.loadApp();
    await mealsPage.goTo();
  });
  test('Deselect daily meal intake in the "What You Eat During the Day" section', async () => {
      await mealsPage.preferenceTab.click();
      await preferencesTab.whatYouEatSection.click();
      await preferencesTab.unselectMorningSnackAndafternoonSnackCheckBoxes();
      //await preferencesTab.whatYouEatSection.click();
  
      //Assertions
      //await expect(preferencesTab.breakfastCheckBox).not.toBeChecked();
      //await expect(preferencesTab.supperCheckBox).not.toBeChecked();
      //await preferencesTab.goBack();
    });
  
    test('Deselect salty breakfast from recipes', async () => {
      await mealsPage.preferenceTab.click();
      await preferencesTab.breakfastSection.click();
      await preferencesTab.unselectSaltBreakfast();
      // await preferencesTab.breakfastSection.click();
  
      // Assertions
      // await preferencesTab.breakfastSection.click();
      // await expect(preferencesTab.saltyCheckBox).not.toBeChecked();
      // await preferencesTab.goBack();
    });
  
    test('Deselect chicken and rabbit ingredients from recipes', async () => {
      await mealsPage.preferenceTab.click();
      await preferencesTab.mainCoursesSection.click();
      await preferencesTab.unselectChikenAndRebbitCeckBoxCards();
      //await preferencesTab.mainCoursesSection.click();
  
      // Assertions
      // await expect(preferencesTab.chieknCheckBoxCard).not.toBeChecked();
      // await expect(preferencesTab.rebbitCheckBoxCard).not.toBeChecked();
      // await preferencesTab.goBack();
    });
  
    test('Deselect salmon, tuna, and seafood ingredients from recipes', async () => {
      await mealsPage.preferenceTab.click();
      await preferencesTab.fishSeafoodSection.click();
      await preferencesTab.unselectSalmonAndTunaAndSeaFoodCheckBoxCards();
      //await preferencesTab.fishSeafoodSection.click();
  
      // Assertions
      // await expect(preferencesTab.salmonCheckBoxCard).not.toBeChecked();
      // await expect(preferencesTab.tunaCheckBoxCard).not.toBeChecked();
      // await expect(preferencesTab.seafoodCheckBoxCard).not.toBeChecked();
      // await preferencesTab.goBack();
    });
  
    test('Deselect pasta, couscous, and bulgur ingredients from recipes', async () => {
      await mealsPage.preferenceTab.click();
      await preferencesTab.extrasSection.click();
      await preferencesTab.unselectPastaAndCouscousAndBulgurCheckBoxCards();
      //await preferencesTab.extrasSection.click();
  
      // Assertions
      // await preferencesTab.fishSeafoodSection.click();
      // await expect(preferencesTab.pastaCheckBoxCard).not.toBeChecked();
      // await expect(preferencesTab.couscousCheckBoxCard).not.toBeChecked();
      // await expect(preferencesTab.bulgurCheckBoxCard).not.toBeChecked();
      // await preferencesTab.goBack();
    });

});