import { test, expect, Locator } from '@playwright/test';
import { MealsTab } from '../../pages/meals-page/tabs/meals-tab';
import { FilterButtonsControl, FilterBodyControl } from '../../shared/components/filtration';
import { MealsPage } from '../../pages/meals-page/meals-page';
import { CartTab } from '../../pages/meals-page/tabs/cart-tab';

test.describe.configure({ mode: 'serial' });
test.use({ contextOptions: { reducedMotion: 'reduce' } });

test.describe('Meals page tests', () => {
  let mealsPage: MealsPage;
  let mealsTab: MealsTab;
  let cartTab: CartTab;

  test.beforeEach(async ({ page }) => {
    mealsPage = new MealsPage(page);
    mealsTab = new MealsTab(page);
    cartTab = new CartTab(page);
    await mealsPage.loadApp();
    await mealsPage.goTo();
  });

  test('Filter breakfast recipes to show only dishes containing with keyword "banan"', async () => {
    await mealsTab.breakfastPage.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.mealInnerPageFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.mealInnerPageFiltration);
    await filterButtonsControl.searchButton.click();
    await filterBodyControl.searchWithFilter('banan');
    const filteredCards = mealsTab.mealCard.filter({ hasText: 'banánem' });
    await expect(filteredCards.first()).toBeVisible({ timeout: 2000 });
    const count = await filteredCards.count();
    expect(count).toBeGreaterThanOrEqual(10);
  });

  test('Filter on Meals tab, lunch recipes to show only "losos" dishes containing ingredient "Kari koření', async () => {
    await mealsPage.mealsTab.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.lunchFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.filterBodyControl);
    await filterButtonsControl.searchButton.click();
    await filterBodyControl.searchWithFilter('losos');
    await filterButtonsControl.filterButton.click();
    await filterBodyControl.addIngredient('Kari');
    await filterBodyControl.showResultsButton.click();
    const filteredCards = mealsTab.mealCard.filter({ hasText: 'Losos na kari' });
    await expect(filteredCards.first()).toBeVisible({ timeout: 2000 });
    const count = await filteredCards.count();
    expect(count).toBeGreaterThanOrEqual(2);
  });

  test('Filter on Meals tab supper recipes using a keyword "treska" and verify filter reset functionality.', async () => {
    await mealsPage.mealsTab.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.supperFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.filterBodyControl);
    await filterButtonsControl.searchButton.click();
    await filterBodyControl.searchWithFilter('treska')
    const filteredCards = mealsTab.mealCard.filter({ hasText: 'treska' });
    await expect(filteredCards.first()).toBeVisible({ timeout: 2000 });
    const count = await filteredCards.count();
    expect(count).toBeGreaterThanOrEqual(3);
    await filterBodyControl.resetFilterButton.click();
  })

  test('Filter by meals complexity filter on lunch recipes', async () => {
    await mealsPage.mealsTab.click();
    await mealsTab.lunchPage.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.mealInnerPageFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.mealInnerPageFiltration);
    await filterButtonsControl.filterButton.click();
    await filterBodyControl.selectComplexityByIndex(1);
    await filterBodyControl.showResultsButton.click();
    const selectedComplexityButton = filterBodyControl.filterMealComplexity.locator('button').nth(1);
    await expect(selectedComplexityButton).toHaveAttribute('aria-pressed', 'true');
    await expect(selectedComplexityButton).toHaveAttribute('data-state', 'on');
  });

  test('Filter supper recipes based on preparation time', async () => {
    await mealsPage.mealsTab.click();
    await mealsTab.supperPage.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.mealInnerPageFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.mealInnerPageFiltration);
    await filterButtonsControl.filterButton.click();
    await filterBodyControl.selectPreparationTimeByIndex(0);
    await filterBodyControl.showResultsButton.click();
    const mealCards = mealsTab.mealCard;
    await expect(mealCards.first()).toBeVisible({ timeout: 1500 });
    const allMealCards = await mealCards.all();
    for (const card of allMealCards) {
      const timeSpan = card.locator(mealsTab.mealTimeSpan);
      const timeText = await timeSpan.innerText();
      const minutes = parseInt(timeText.split(' ')[0]);
      expect(minutes).toBeLessThan(61);
    }
  });

  test('Filter lunch recipes by specific ingredient "Med"', async () => {
    await mealsPage.mealsTab.click();
    await mealsTab.lunchPage.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.mealInnerPageFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.mealInnerPageFiltration);
    await filterButtonsControl.filterButton.click();
    await filterBodyControl.addIngredient('Med');
    await expect(filterBodyControl.ingredienceBadge).toContainText('Med');
  });

  test('Filter morning snack meals by multiple ingredients', async () => {
    await mealsTab.morningSnackFiltration.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.morningSnackFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.filterBodyControl);
    await filterButtonsControl.filterButton.click();
    await filterBodyControl.addIngredient('Wrap');
    await filterBodyControl.addIngredient('Hummus');
    await filterBodyControl.addIngredient('Cuketa');
    await filterBodyControl.showResultsButton.click();
    const filteredCards = mealsTab.mealCard.filter({ hasText: 'wrap s hummusem'});
    await expect(filteredCards.first()).toBeVisible({ timeout: 1000 });
  });

  test('Remove all applied filters via filter controls', async ({page}) => {
    await mealsPage.mealsTab.click();
    const filterButtonsControl = new FilterButtonsControl(mealsTab.lunchFiltration);
    const filterBodyControl = new FilterBodyControl(mealsTab.filterBodyControl);
    await filterButtonsControl.searchButton.click();
    await filterBodyControl.searchWithFilter('losos');
    await filterBodyControl.showResultsButton.click();
    await filterButtonsControl.filterButton.click();
    await filterBodyControl.selectComplexityByIndex(2);
    await filterBodyControl.selectPreparationTimeByIndex(2);
    await filterBodyControl.addIngredient('Brambory');
    await filterBodyControl.showResultsButton.click();
    //to finish remove functionality
    // await filterButtonsControl.cancelSearchButton.click();
    // await filterButtonsControl.cancelFilterButton.click();
  });

  test('Filter breakfast meals by quick filtration', async () => {
    await mealsPage.mealsTab.click();
    mealsTab.selectQuickFilterByIndex(mealsTab.breakfastQuickFilters, 4);
    const selectedFilterButton = mealsTab.breakfastQuickFilters.locator('button').nth(4);
    await expect(selectedFilterButton).toHaveAttribute('aria-checked', 'true');
    await expect(selectedFilterButton).toHaveAttribute('data-state', 'on');
  });

  test('Filter lunch section meals by quick filtration', async () => {
    await mealsTab.lunchPage.click();
    mealsTab.selectQuickFilterByIndex(mealsTab.mealInnerPageFiltration, 5);
    const selectedFilterButton = mealsTab.mealInnerPageFiltration.locator('button').nth(5);
    await expect(selectedFilterButton).toHaveAttribute('aria-checked', 'true');
    await expect(selectedFilterButton).toHaveAttribute('data-state', 'on');
  });

  test('Vertical scroll in morning snack section', async ({ page }) => {
    await mealsTab.morningSnackPage.click();
    await page.waitForTimeout(1000);
    const mealCardsBefore = await mealsTab.countMealCardsInModal();
    console.log({ mealCardsBefore });
    const scrollContainer = page.locator('[data-component="Modal"] section[data-component="MealsSection"]');
    await scrollContainer.evaluate(async (el) => {
      const delay = (ms: number) => new Promise(res => setTimeout(res, ms));
      for (let i = 0; i < 5; i++) {
        el.scrollTop += 3000;
        await delay(1000);
      }
    });
    await page.waitForTimeout(1000);
    const mealCardsAfter = await mealsTab.countMealCardsInModal();
    console.log({ mealCardsAfter });
    expect(mealCardsAfter).toBeGreaterThan(mealCardsBefore);
  });

  test('Horizontal scroll in lunch carousel and show all', async ({ page }) => {
    await mealsPage.mealsTab.click();
    await page.waitForTimeout(1000);
    const mealCardsBefore = await mealsTab.breakfastSection.locator("div[data-component='GenericCarousel'] div[data-component='MealCard']").count();
    console.log({ mealCardsBefore });
    await page.waitForTimeout(1000);
    const scrollContainer = page.locator('div[data-component="carousel"].overflow-auto').nth(0);
    await scrollContainer.hover();
    await page.mouse.wheel(10000, 0);
    await page.waitForTimeout(1000);
    await mealsTab.clickOnShowMoreButton(mealsTab.breakfastSection);
    await page.waitForTimeout(1000);
    const mealCardsAfter = await mealsTab.breakfastSection.locator("div[data-component='GenericCarousel'] div[data-component='MealCard']").count();
    console.log({ mealCardsAfter });
    expect(mealCardsAfter).toBeGreaterThan(mealCardsBefore);
  });
  
  test('Adding meals to the cart from Melas tab', async ({ page }) => {
    await mealsPage.mealsTab.click();
    await mealsTab.clickAddToBasketByIndex([0, 11, 21, 31, 41]);
    await mealsPage.cartTab.click();
    await page.waitForTimeout(1000);
    await expect(cartTab.getMealCount()).resolves.toBe(5);
    await cartTab.removeAllItemsFromCart();
    await expect(cartTab.emptyCartText).toBeVisible();
    await expect(cartTab.visitMealsTabButton).toBeVisible();
  });
});
