import { test, expect } from '@playwright/test';
import { HomePage } from '../../pages/home-page/home-page';

test.describe('Menu Tests', () => {
  let homePage: HomePage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    await homePage.loadApp();
  });

  test('has title', async ({ page }) => {
    await expect(page).toHaveTitle(/ALESLIM/);
  });
});
