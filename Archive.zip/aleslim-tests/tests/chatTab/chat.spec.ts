import { test, expect } from '@playwright/test';
import { ChatPage } from '../../pages/chat-page/chat-page';

test.describe('Chat Tests', () => {
  let chatPage: ChatPage;

  test.beforeEach(async ({ page }) => {
    chatPage = new ChatPage(page);
    await chatPage.loadPage();
  });

  test('ChatInput is visible', async () => {
    await expect(chatPage.chatInput).toBeVisible();
  });

  test('ChatMessages are visible', async () => {
    await expect(chatPage.chatMessages).toBeVisible();
  });

  test('Welcome message displayed', async () => {
    const welcomeMessage = await chatPage.getWelcomeMessage();
    const welcomeMessageResult = 'Dobrý den, jsem Váš osobní nutriční specialista. Neváhejte se na mě kdykoliv obracet. Jsem tu vždy pro Vás 😊';
    expect(welcomeMessage).toEqual(welcomeMessageResult);
  });
});
