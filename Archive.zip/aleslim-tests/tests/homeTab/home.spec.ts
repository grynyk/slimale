import { test, expect, Locator } from '@playwright/test';
import { HomePage } from '../../pages/home-page/home-page';
import { FooterNavigation } from '../../shared/components/footer-navigation';
import { AppPage } from '../../shared/app-page';


test.describe('Home Page Tests', () => {
  let homePage: HomePage;
  let appPage: AppPage;
  let footerNavigation: FooterNavigation;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    await homePage.loadApp();
    appPage = new AppPage(page);
    footerNavigation = new FooterNavigation(page);
  });

  test('Verify app title', async ({ page }) => {
    await expect(page).toHaveTitle(/ALESLIM/);
  });

  test('Footer is visible', async () => {
    await expect(footerNavigation.footer).toBeVisible();
  });

  test('Home page is visible and active', async () => {
    const homeButton: Locator = footerNavigation.homeButton;
    await homeButton.click();
    const homeButtonAriaAttribute: string | null = await homeButton.getAttribute('aria-current');
    await expect(homeButton).toBeVisible();
    await expect(homeButton).toHaveText('Domů');
    expect(homeButtonAriaAttribute).toEqual('page');
  });

  test('Meals page is visible and active', async () => {
    const mealsButton: Locator = footerNavigation.mealsButton;
    await mealsButton.click();
    const mealsButtonAriaAttribute: string | null = await mealsButton.getAttribute('aria-current');
    await expect(mealsButton).toBeVisible();
    await expect(mealsButton).toHaveText('Jídlo')
    expect(mealsButtonAriaAttribute).toEqual('page');
  });

  test('Photo page is visible and active', async () => {
    const photoButton: Locator = footerNavigation.photoButton;
    await photoButton.click();
    await expect(photoButton).toBeVisible();
    await expect(photoButton).toHaveText('Foto')
    expect(await photoButton.getAttribute('aria-current')).toEqual('page');
  });

  test('My journal page is visible and active', async () => {
    const profileButton: Locator = footerNavigation.profileButton;
    await profileButton.click();
    await expect(profileButton).toBeVisible();
    await expect(profileButton).toHaveText('Deník')
    expect(await profileButton.getAttribute('aria-current')).toEqual('page');
  });
});
