import { expect, Locator, Page } from '@playwright/test';
import { MealsPage } from '../meals-page';

export class PreferenceTab extends MealsPage {
  tabpanel: Locator;
  checkboxField: Locator;
  createRecipesButton: Locator;
  whatYouEatSection: Locator;
  breakfastSection: Locator;
  mainCoursesSection: Locator;
  fishSeafoodSection: Locator;
  extrasSection: Locator;
  //Daily taken meals preferences  
  breakfastCheckBox: Locator;
  morningSnackCheckBox: Locator;
  lunchCheckBox: Locator;
  afternoonSnackCheckBox: Locator;
  supperCheckBox: Locator;
  //Breakfast preferences 
  sweetCheckbox: Locator;
  saltyCheckBox: Locator;
  //Main dishes preferences section 
  checkBoxCard: Locator;
  chieknCheckBoxCard: Locator;
  rebbitCheckBoxCard: Locator;
  //Fish and seafood section 
  salmonCheckBoxCard: Locator;
  tunaCheckBoxCard: Locator;
  seafoodCheckBoxCard: Locator;
  //Wxtras section
  pastaCheckBoxCard: Locator;
  couscousCheckBoxCard: Locator
  bulgurCheckBoxCard: Locator;

  constructor(page: Page) {
    super(page);
    this.createRecipesButton = this.page.locator('button', { hasText: 'Vytvořit recepty' })
    this.tabpanel = this.page.locator('div[role="tabpanel"]')
    this.checkboxField = this.page.getByTestId('CheckboxField');
    this.checkBoxCard = this.page.getByTestId('ChackboxCard');
    //Preferences sections
    this.whatYouEatSection = this.tabpanel.locator('button').nth(0);
    this.breakfastSection = this.tabpanel.locator('button').nth(1);
    this.mainCoursesSection = this.tabpanel.locator('button').nth(2);
    this.fishSeafoodSection = this.tabpanel.locator('button').nth(3);
    this.extrasSection = this.tabpanel.locator('button').nth(4);
    //Types of meals consuumed during the day selectors
    this.breakfastCheckBox = this.page.locator('button[role="checkbox"]').nth(0);
    this.morningSnackCheckBox = this.checkboxField.getByRole('checkbox', { name: 'Dopolední svačina' });
    this.lunchCheckBox = this.page.locator('button[role="checkbox"]').nth(2);
    this.afternoonSnackCheckBox = this.checkboxField.getByRole('checkbox', { name: 'Odpolední svačina' });
    this.supperCheckBox = this.page.locator('button[role="checkbox"]').nth(4);
    //Breakfast section selectors
    this.sweetCheckbox = this.checkboxField.locator('button[role="checkbox"]').nth(0);
    this.saltyCheckBox = this.checkboxField.locator('button[role="checkbox"]').nth(1);
    //Main Dishes selectors 
    this.chieknCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(0);
    this.rebbitCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(7);
    //Fish and Seafoods selectors 
    this.salmonCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(0);
    this.tunaCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(1);
    this.seafoodCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(8);
    //Extras selectors 
    this.pastaCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(5);
    this.couscousCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(7);
    this.bulgurCheckBoxCard = this.page.locator('button[role="checkbox"]').nth(11);

  }
  async unselectMorningSnackAndafternoonSnackCheckBoxes(): Promise<void> {
    await this.morningSnackCheckBox.click();
    await this.afternoonSnackCheckBox.click();
    await this.createRecipesButton.click();
  }

  async unselectSaltBreakfast(): Promise<void> {
    await this.saltyCheckBox.uncheck();
    await this.createRecipesButton.click();
  }

  async unselectChikenAndRebbitCeckBoxCards(): Promise<void> {
    await this.chieknCheckBoxCard.click();
    await this.rebbitCheckBoxCard.click();
    await this.createRecipesButton.click();
  }

  async unselectSalmonAndTunaAndSeaFoodCheckBoxCards(): Promise<void> {
    await this.salmonCheckBoxCard.click();
    await this.tunaCheckBoxCard.click();
    await this.seafoodCheckBoxCard.click();
    await this.createRecipesButton.click();
  }
  async unselectPastaAndCouscousAndBulgurCheckBoxCards(): Promise<void> {
    await this.pastaCheckBoxCard.click();
    await this.couscousCheckBoxCard.click();
    await this.bulgurCheckBoxCard.click();
    await this.createRecipesButton.click();
    await this.extrasSection.click();
  }


}
