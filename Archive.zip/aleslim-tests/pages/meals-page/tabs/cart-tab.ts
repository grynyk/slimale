import { Page, Locator } from '@playwright/test';
import { MealsPage } from '../meals-page';

export class CartTab extends MealsPage {
  shoppingCartMealsList: Locator;
  removeAllMealsButton: Locator;
  removeSpecificItemButton: Locator;
  confirmRemoveAllMealsButton: Locator;
  cancelRemoveAllMealsButton: Locator;
  visitMealsTabButton: Locator;
  dishImage: Locator;
  emptyCartText: Locator;
  showIngredientsButton: Locator;
  sendEmailButton: Locator;
  moveToCookButton: Locator;
  toastConfirmationMessage: Locator;
  shoppingCartCustomItems: Locator;
  addCustomIngredience: Locator;
  customIngredientInput: Locator;
  removeIngredientButton: Locator;


  constructor(page: Page) {
    super(page);
    this.shoppingCartMealsList = this.page.locator('article[data-component="ShoppingCartMealsList"]');
    this.removeSpecificItemButton = this.page.getByTestId('IconTrash');
    this.removeAllMealsButton = this.page.locator('button', { hasText: 'Odstranit vše' });
    this.confirmRemoveAllMealsButton = this.page.locator('button', {hasText: 'Ano, odstranit'});
    this.cancelRemoveAllMealsButton = this.page.locator('button', {hasText: 'Ne'});
    this.dishImage = this.page.locator('article').getByAltText('Dish');
    this.visitMealsTabButton = this.page.locator('button', { hasText: 'Otevřít jídla' });
    this.emptyCartText = this.page.locator('h4', { hasText: 'Nákupní seznam je prázdný :(' });
    this.showIngredientsButton = this.page.locator('button', { hasText: 'Zobrazit nákupní seznam' });
    this.sendEmailButton = this.page.locator('button .lucide.lucide-mail');
    this.moveToCookButton = this.page.locator('button .lucide.lucide-utensils');
    this.toastConfirmationMessage = this.page.getByTestId('toaster');
    this.shoppingCartCustomItems = this.page.getByTestId('ShoppingCartCustomItem');
    this.addCustomIngredience = this.shoppingCartCustomItems.getByText('Zadej název položky...');
    this.customIngredientInput = this.shoppingCartCustomItems.locator('input[placeholder="Zadej název položky..."]');
    this.removeIngredientButton = this.shoppingCartCustomItems.getByTestId('IconTrash').first();


  }

  async getMealCount(): Promise<number> {
    return this.dishImage.count();
  }
  
  async removeSpecificItemFromCart(index: number): Promise<void> {
    await this.removeSpecificItemButton.nth(index).click();
  }
  
  async removeAllItemsFromCart(): Promise<void> {
    await this.removeAllMealsButton.click();
    await this.confirmRemoveAllMealsButton.click();
  }
  
  async addCustomIngredient(name: string): Promise<void> {
    await this.addCustomIngredience.click();
    await this.customIngredientInput.fill(name);
    await this.page.keyboard.press('Enter');
  }
  
  async removeCustomIngredient(): Promise<void> {
    await this.removeIngredientButton.click();
  }
}
