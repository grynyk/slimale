import { Page, Locator } from '@playwright/test';
import { MealsPage } from '../meals-page';

export class MealsTab extends MealsPage {
    breakfastPage: Locator;
    morningSnackPage: Locator; 
    lunchPage: Locator;
    afternoonSnackPage: Locator; 
    supperPage: Locator;
    // Sections
    breakfastSection: Locator;
    morningSnackSection: Locator; 
    lunchSection: Locator;
    afternoonSnackSection: Locator; 
    supperSection: Locator;
    // Filtration
    mealsTabFiltration: Locator;
    breakfastFiltration: Locator;
    morningSnackFiltration: Locator;
    lunchFiltration: Locator;
    afternoonSnackFiltration: Locator;
    supperFiltration: Locator;
    mealInnerPageFiltration: Locator;
    // Quick Filters
    breakfastQuickFilters: Locator;
    morningSnackQuickFilters: Locator;
    lunchQuickFilters: Locator;
    afternoonSnackQuickFilters: Locator;
    supperQuickFilters: Locator;
    // FilterBodyControl
    filterBodyControl: Locator;
    // MealCard
    mealCard: Locator;
    mealTimeSpan: Locator;
    genericCarousel: Locator;
    showMoreButton: Locator;


  constructor(page: Page) {
    super(page);
    const mealsSections: Locator = this.page.getByTestId('MealsSection');
    this.breakfastSection = this.page.getByTestId('MealsSection').nth(0);
    this.morningSnackSection = this.page.getByTestId('MealsSection').nth(1);
    this.lunchSection = this.page.getByTestId('MealsSection').nth(2);
    this.afternoonSnackSection = this.page.getByTestId('MealsSection').nth(3);
    this.supperSection = this.page.getByTestId('MealsSection').nth(4);

    this.breakfastPage = this.breakfastSection.getByText('Snídaně');
    this.morningSnackPage = this.morningSnackSection.getByText('Dopolední');
    this.lunchPage = this.lunchSection.getByText('Oběd');
    this.afternoonSnackPage = this.afternoonSnackSection.getByText('Odpolední');
    this.supperPage = this.supperSection.getByText('Večeře');

    this.mealsTabFiltration = this.page.getByTestId('ButtonsControl');
    this.breakfastFiltration = this.breakfastSection.getByTestId('ButtonsControl');
    this.morningSnackFiltration = this.morningSnackSection.getByTestId('ButtonsControl');
    this.lunchFiltration = this.lunchSection.getByTestId('ButtonsControl');
    this.afternoonSnackFiltration = this.afternoonSnackSection.getByTestId('ButtonsControl');
    this.supperFiltration = this.supperSection.getByTestId('ButtonsControl');
    this.mealInnerPageFiltration = this.page.locator('.modal-section');
    
    this.breakfastQuickFilters = this.breakfastSection.locator('div[role="group"]');
    this.morningSnackQuickFilters = this.morningSnackSection.locator('div[role="group"]');
    this.lunchQuickFilters = this.lunchSection.locator('div[role="group"]');
    this.afternoonSnackQuickFilters = this.afternoonSnackSection.locator('div[role="group"]');
    this.supperQuickFilters = this.supperSection.locator('div[role="group"]');

    this.filterBodyControl = this.page.getByTestId('FilterBodyControl');

    this.mealCard = this.page.getByTestId('MealCard');
    this.mealTimeSpan = this.page.locator('span', { hasText: ' min' });
    this.genericCarousel = this.page.getByTestId('GenericCarousel');
    this.showMoreButton = this.page.getByTestId('MealEmptyCard');
  }

  async selectQuickFilterByIndex(quickFilters: Locator, index: number): Promise<void> {
    await quickFilters.locator('button').nth(index).click();
  }

  async countMealCardsInModal(): Promise<number> {
    return await this.page.locator("div[data-component='Modal'] div[data-component='MealCard']").count();
  }

  async clickOnShowMoreButton(section: Locator): Promise<void> {
    const showMoreButton = section.getByTestId('MealEmptyCard');
    await showMoreButton.click();
  }
  
}
