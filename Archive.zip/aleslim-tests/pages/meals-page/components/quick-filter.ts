import { Locator } from "@playwright/test";

export class QuickFilterComponent {
    mealsSections: Locator;
    breakfastQuickFilter: Locator;
    morningSnackQuickFilter: Locator; 
    lunchQuickFilter: Locator; 
    afternoonSnackQuickFilter: Locator;
    supperQuickFilter: Locator;

    constructor(parentLocator: Locator) {
        this.mealsSections = parentLocator.getByTestId('ButtonsControl');
        this.breakfastQuickFilter = parentLocator.locator('button .lucide.lucide-search');
        this.morningSnackQuickFilter = parentLocator.locator('button:has(.lucide-filter)');
        this.lunchQuickFilter = parentLocator.locator('button .lucide.lucide-search');
        this.afternoonSnackQuickFilter = parentLocator.locator('button:has(.lucide-filter)');
        this.supperQuickFilter = parentLocator.locator('button .lucide.lucide-search');
    }
}

