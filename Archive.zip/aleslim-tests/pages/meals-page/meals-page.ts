import { Locator, Page } from '@playwright/test';
import { AppPage } from '../../shared/app-page';
import { APP_URL } from '../../constants/url';

export class MealsPage extends AppPage {
  tabList: Locator;
  mealsTab: Locator;
  cartTab: Locator;
  preferenceTab: Locator;
  cancelFilterButton: Locator;
  addToBasketButton: Locator;
  addToFavoritesButton: Locator;

  constructor(page: Page) {
    super(page);
    this.tabList = this.page.locator('div[role="tablist"]');

    this.mealsTab = this.tabList.locator('button[role="tab"]').nth(0);
    this.cartTab = this.tabList.locator('button[role="tab"]').nth(1);
    this.preferenceTab = this.tabList.locator('button[role="tab"]').nth(2);

    this.cancelFilterButton = this.page.locator('');
    this.addToBasketButton = this.page.locator('button', { hasText: 'Přidat do seznamu' });
    this.addToFavoritesButton = this.page.locator('');
  }
  async goTo(): Promise<void> {
    await this.page.goto(`${APP_URL}/meals`);
  }

  async clickAddToBasketByIndex(indices: number[]) {
    for (const index of indices) {
      await this.addToBasketButton.nth(index).click();
    }
  }

}
