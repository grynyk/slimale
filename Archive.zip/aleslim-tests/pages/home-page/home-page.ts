import { Locator, Page } from '@playwright/test';
import { AppPage } from '../../shared/app-page';

export class HomePage extends AppPage {
  menuButton: Locator;


  constructor(page: Page) {
    super(page);
    const header: Locator = this.page.getByTestId('Header');
    this.menuButton = header.locator('button');
  }

  async clickOnMenuButton (): Promise<void>{
    await this.menuButton.click();
  }

}
