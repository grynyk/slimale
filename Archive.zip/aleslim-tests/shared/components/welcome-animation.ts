import { Locator, Page } from "@playwright/test";
import { BasePage } from "../base-page";

export class WelcomeAnimation extends BasePage {

    constructor(page: Page) {
        super(page)
    }

    async skipWelcomeAnimation(): Promise<void> {
        await this.page.click('body');
    }
    
}