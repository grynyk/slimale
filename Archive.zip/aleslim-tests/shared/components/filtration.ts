import { Locator } from "@playwright/test";

export class FilterButtonsControl {
    searchButton: Locator;
    filterButton: Locator;
    cancelSearchButton: Locator;
    cancelFilterButton: Locator;

    constructor(buttonControl: Locator) {
        this.searchButton = buttonControl.locator('button .lucide.lucide-search').first();
        this.filterButton = buttonControl.getByTestId('IconFilter');
        this.cancelSearchButton = buttonControl.locator('button .lucide.lucide-x')
        this.cancelFilterButton = buttonControl.locator('button .lucide.lucide-x')
    }

}

export class FilterBodyControl {
    filterBodyControl: Locator;
    searchFilterInput: Locator;
    showResultsButton: Locator;
    resetFilterButton: Locator;
    filterMealComplexity: Locator;
    filterMealPreparationTime: Locator;
    filterIngredientInput: Locator;
    ingredienceBadge: Locator;

    constructor(filterBodyControl: Locator) {
        this.filterBodyControl = filterBodyControl;
        this.searchFilterInput = filterBodyControl.getByTestId('input');
        this.showResultsButton = filterBodyControl.getByRole('button', { name: 'Zobrazit výsledky' }).first();
        this.resetFilterButton = filterBodyControl.getByRole('button', { name: 'Zrušit filtr' }).first();
        this.filterMealComplexity = filterBodyControl.locator('div[role="group"]').nth(0);
        this.filterMealPreparationTime = filterBodyControl.locator('div[role="group"]').nth(1);
        this.filterIngredientInput = filterBodyControl.getByTestId('tags-input').locator('input');
        this.ingredienceBadge = filterBodyControl.getByTestId('Badge');
    };

    async selectComplexityByIndex(index: number): Promise<void> {
        await this.filterMealComplexity.locator('button').nth(index).click();
    };
    async selectPreparationTimeByIndex(index: number): Promise<void> {
        await this.filterMealPreparationTime.locator('button').nth(index).click();
    };
    async selectIngredientByIndex(index: number): Promise<void> {
        await this.filterBodyControl.locator('div[role="option"]').nth(index).click();
    };
    async addIngredient(ingredient: string): Promise<void> {
        await this.filterIngredientInput.click();
        await this.filterIngredientInput.fill(ingredient);
        await this.selectIngredientByIndex(0);
    };
    async searchWithFilter(text: string): Promise<void> {
        await this.searchFilterInput.fill(text);
        await this.showResultsButton.click();
    };
}



