import { Locator, Page } from '@playwright/test';
import { AppPage } from '../../shared/app-page';

export class HomePage extends AppPage {
  menuButton: Locator;


  constructor(page: Page) {
    super(page);
    this.menuButton = this.page.locator('//html/body/div[1]/header/button');
  }

  async clickOnMenuButton (): Promise<void>{
    await this.menuButton.click();
  }

}
