import { Page } from '@playwright/test';
import { BasePage } from '../../shared/base-page';
import { QUIZ_URL } from '../../constants/url';

export class QuizPage extends BasePage {
  constructor(page: Page) {
    super(page);
  }

  async goTo(): Promise<void> {
    await this.page.goto(QUIZ_URL);
  }
}
