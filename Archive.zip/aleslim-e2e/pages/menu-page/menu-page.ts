import { Locator, Page } from '@playwright/test';
import { BasePage } from '../../shared/base-page';

export class MenuPage extends BasePage {
  settigsTabButton: Locator;
  logoutButton: Locator;
  logoutConfirmationDialog: Locator;
  logoutConfirmationBtn: Locator;
  
  constructor(page: Page) {
    super(page);
    this.settigsTabButton = this.page.locator('a[href="/settings"]');
    this.logoutButton = this.page.locator('//button[contains(text(), "Odhlásit se")]');
    this.logoutConfirmationDialog = this.page.locator('div[data-component="DrawerFooter"]')
    this.logoutConfirmationBtn = this.page.locator('div[data-component="DrawerFooter"] button:has-text("Odhlásit se")')
  }

  async clickOnSettings(): Promise<void> {
    await this.settigsTabButton.click();
  }

  async clickOnLogoutButton(): Promise<void> {
    await this.logoutButton.click();
    await this.logoutConfirmationDialog.waitFor({ state: 'visible' });
    await this.logoutConfirmationBtn.click();
  }
}
