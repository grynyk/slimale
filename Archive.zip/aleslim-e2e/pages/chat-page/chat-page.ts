import { Locator, Page } from '@playwright/test';
import { AppPage } from '../../shared/app-page';
import { FooterNavigation } from '../../shared/components/footer-navigation';

export class ChatPage extends AppPage {
  chatInput: Locator;
  chatMessages: Locator;
  footerNavigation: FooterNavigation;
  footerNavigationButton: Locator

  constructor(page: Page) {
    super(page);
    this.footerNavigation = new FooterNavigation(page);
    this.footerNavigationButton = this.footerNavigation.chatButton;
    this.chatInput = page.getByTestId('TextInput');
    this.chatMessages = page.getByTestId('ChatMessages');
  }

  async loadPage(): Promise<void> {
    this.loadApp();
    await this.footerNavigationButton.click();
  }

  async getWelcomeMessage(): Promise<string> {
    const firstMessage: string = await this.chatMessages.getByTestId('ChatMessage').first().locator('.text-base').innerText();
    return firstMessage.trim();
  }
}