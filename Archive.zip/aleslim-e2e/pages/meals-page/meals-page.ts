import { Page } from '@playwright/test';
import { AppPage } from '../../shared/app-page';

export class MealsPage extends AppPage {
  constructor(page: Page) {
    super(page);
  }
}
