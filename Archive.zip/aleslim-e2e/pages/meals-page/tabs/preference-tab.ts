import { Page } from '@playwright/test';
import { MealsPage } from '../meals-page';

export class PreferenceTab extends MealsPage {
  constructor(page: Page) {
    super(page);
  }
}
