import { Page } from '@playwright/test';
import { MealsPage } from '../meals-page';

export class CartTab extends MealsPage {
  constructor(page: Page) {
    super(page);
  }
}
