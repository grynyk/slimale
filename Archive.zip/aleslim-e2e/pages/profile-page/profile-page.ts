import { Page } from '@playwright/test';
import { BasePage } from '../../shared/base-page';

export class ProfilePage extends BasePage {
  constructor(page: Page) {
    super(page);
  }
}
