import { Locator, Page } from '@playwright/test';
import { BasePage } from '../../shared/base-page';
import { APP_URL } from '../../constants/url';

export class LoginPage extends BasePage {
  emailInput: Locator;
  passwordInput: Locator;
  loginButton: Locator;
  emailLabel: Locator;
  resetPasswordButton: Locator;

  //Error and Confirmation messages locators
  emailErrorMessage: Locator;
  passwordErrorMessage: Locator;
  resetEmailConfirmationMessage: Locator;
  userNotFoundMessage: Locator;

  constructor(page: Page) {
    super(page);
    this.emailInput = this.page.locator('input[name="email"]');
    this.passwordInput = this.page.locator('input[name="password"]');
    this.loginButton = this.page.locator('button[type="submit"]');
    this.emailLabel = this.page.getByText('E-mail', { exact: true });
    this.resetPasswordButton = this.page.locator('button[type="button"]',{hasText: 'Zapomenuté heslo?'})
    this.emailErrorMessage = this.page.locator('p.text-destructive', { hasText: 'Neplatný e-mail.' });
    this.passwordErrorMessage = this.page.locator('p.text-destructive', { hasText: 'Chyba, heslo je neplatné' });
    this.resetEmailConfirmationMessage = this.page.locator('div.mt-4.rounded-2xl.bg-teal-100.p-4 > p');
    this.userNotFoundMessage = this.page.locator('p.text-destructive', {hasText: 'Uživatel nebyl nalezen'});
  }

  async goTo(): Promise<void> {
    await this.page.goto(`${APP_URL}/login`);
  }

  async login(
    email: string,
    password: string
  ): Promise<void> {
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }
}
