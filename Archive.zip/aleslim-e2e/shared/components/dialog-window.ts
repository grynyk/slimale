import { Locator, Page } from "@playwright/test";
import { BasePage } from "../base-page";

export class DialogWindow extends BasePage {
    cancelPopUpBtn: Locator;

    constructor(page: Page) {
        super(page)
        this.cancelPopUpBtn = this.page.locator('//html/body/div[3]/button/span');
    }

    async cancel(): Promise<void> {
        await this.cancelPopUpBtn.click();
    }
}

