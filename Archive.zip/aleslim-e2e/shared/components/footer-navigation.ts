import { Locator, Page } from "@playwright/test";
import { BasePage } from "../base-page";

export class FooterNavigation extends BasePage {
  footer: Locator;
  navigation: Locator;
  homeButton: Locator;
  mealsButton: Locator;
  chatButton: Locator;
  photoButton: Locator;
  profileButton: Locator;

  constructor(page: Page) {
    super(page);
    this.footer = this.page.locator('footer');
    this.navigation = this.page.getByTestId('Footer');
    this.homeButton = this.navigation.locator('a').nth(0);
    this.mealsButton = this.navigation.locator('a').nth(1);
    this.chatButton = this.navigation.locator('a').nth(2);
    this.photoButton = this.navigation.locator('a').nth(3);
    this.profileButton = this.navigation.locator('a').nth(4);
  }
}
