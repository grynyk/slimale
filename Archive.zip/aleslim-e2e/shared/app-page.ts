import { Page } from '@playwright/test';
import { BasePage } from './base-page';
import { LoginPage } from '../pages/login-page/login-page';
import { DialogWindow } from './components/dialog-window';
import { credentials } from '../constants/credentials';
import { APP_URL } from '../constants/url';
import { WelcomeAnimation } from './components/welcome-animation';

export class AppPage extends BasePage {
    loginPage: LoginPage;
    dialogWindow: DialogWindow;
    welcomeAnimation: WelcomeAnimation;

    constructor(page: Page) {
        super(page);
        this.loginPage = new LoginPage(page);
        this.dialogWindow = new DialogWindow(page);
        this.welcomeAnimation = new WelcomeAnimation(page);
    }

    async loadApp(): Promise<void> {
        await this.page.goto(APP_URL);
        await this.loginPage.login(credentials.valid.EMAIL, credentials.valid.PASSWORD);
        await this.dialogWindow.cancel();
        await this.welcomeAnimation.skipWelcomeAnimation();
    }
}
