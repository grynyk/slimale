import { test, expect, Locator } from '@playwright/test';
import { FooterNavigation } from '../shared/components/footer-navigation';
import { AppPage } from '../shared/app-page';

test.describe('Footer Navigation Tests', () => {
  let appPage: AppPage;
  let footerNavigation: FooterNavigation;

  test.beforeEach(async ({ page }) => {
    appPage = new AppPage(page);
    footerNavigation = new FooterNavigation(page);
    await appPage.loadApp();
  });

  test('Footer is visible', async () => {
    await expect(footerNavigation.footer).toBeVisible();
  });

  test('Home button is visible and active', async () => {
    const homeButton: Locator = footerNavigation.homeButton;
    await homeButton.click();
    const homeButtonAriaAttribute: string | null = await homeButton.getAttribute('aria-current');
    await expect(homeButton).toBeVisible();
    await expect(homeButton).toHaveText('Domů');
    expect(homeButtonAriaAttribute).toEqual('page');
  });

  test('Meals button is visible and active', async () => {
    const mealsButton: Locator = footerNavigation.mealsButton;
    await mealsButton.click();
    const mealsButtonAriaAttribute: string | null = await mealsButton.getAttribute('aria-current');
    await expect(mealsButton).toBeVisible();
    await expect(mealsButton).toHaveText('Jídlo')
    expect(mealsButtonAriaAttribute).toEqual('page');
  });

  test('Photo button is visible and active', async () => {
    const photoButton: Locator = footerNavigation.photoButton;
    await photoButton.click();
    await expect(photoButton).toBeVisible();
    await expect(photoButton).toHaveText('Foto')
    expect(await photoButton.getAttribute('aria-current')).toEqual('page');
  });

  test('Profile button is visible and active', async () => {
    const profileButton: Locator = footerNavigation.profileButton;
    await profileButton.click();
    await expect(profileButton).toBeVisible();
    await expect(profileButton).toHaveText('Deník')
    expect(await profileButton.getAttribute('aria-current')).toEqual('page');
  });
});
