import { test, expect } from '@playwright/test';
import { QuizPage } from '../pages/quiz-page/quiz-page';

test.describe('Quiz Tests', () => {
  let quizPage: QuizPage;

  test.beforeEach(async ({ page }) => {
    quizPage = new QuizPage(page);
    await quizPage.goTo();
  });

  test('has title', async ({ page }) => {
    await expect(page).toHaveTitle(/Aleslim/);
  });
});
