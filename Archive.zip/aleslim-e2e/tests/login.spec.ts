import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/login-page/login-page';
import { credentials } from '../constants/credentials';
import { HomePage } from '../pages/home-page/home-page';
import { MenuPage } from '../pages/menu-page/menu-page';
import { FooterNavigation } from '../shared/components/footer-navigation';

test.describe('Login Functionality', () => {
  let loginPage: LoginPage;
  let homePage: HomePage;
  let menuPage: MenuPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    homePage = new HomePage(page);
    menuPage = new MenuPage(page);
    await loginPage.goTo();
  });

  test('login page navigation', async ({ page }) => {
    await expect(page).toHaveTitle(/ALESLIM/);
  });

  test('successful login with correct email and password', async ({ page }) => {
    await loginPage.login(credentials.valid.EMAIL, credentials.valid.PASSWORD);
    await expect(page.getByText('Ahoj')).toBeVisible();
    await expect(homePage.menuButton).toBeVisible();
    const footerNavigation = new FooterNavigation(page);
    await expect(footerNavigation.footer).toBeVisible();
  });

  test('login fails with invalid email', async () => {
    await loginPage.login(credentials.invalid.EMAIL, credentials.valid.PASSWORD);
    await expect(loginPage.emailErrorMessage).toBeVisible();
    await expect(loginPage.emailErrorMessage).toHaveText('Neplatný e-mail.');
  });

  test('login fails with incorrect password', async () => {
    await loginPage.login(credentials.valid.EMAIL, credentials.invalid.PASSWORD);
    await expect(loginPage.passwordErrorMessage).toBeVisible();
    await expect(loginPage.passwordErrorMessage).toHaveText('Chyba, heslo je neplatné');
  });

  test('password reset link is sent for valid user', async() =>  {
    await loginPage.goTo();
    await loginPage.resetPasswordButton.click();
    await loginPage.emailInput.fill(credentials.valid.EMAIL)
    await loginPage.loginButton.click();
    await expect(loginPage.resetEmailConfirmationMessage).toBeVisible();
    await expect(loginPage.resetEmailConfirmationMessage).toHaveText('Odkaz k obnově hesla byl odeslán na váš e-mail.');
  });

  test('password reset fails for invalid user', async() =>  {
    await loginPage.resetPasswordButton.click();
    await loginPage.emailInput.fill('realdonaldtrump@gmail.com')
    await loginPage.loginButton.click();
    await expect(loginPage.userNotFoundMessage).toBeVisible();
  });

  test('logout functionality redirects to login page', async()=>{
    await homePage.loadApp();
    await homePage.clickOnMenuButton();
    await menuPage.clickOnSettings();
    await menuPage.clickOnLogoutButton();
    await expect(loginPage.page).toHaveTitle(/ALESLIM/);
    await expect(loginPage.emailInput).toBeVisible();
    await expect(loginPage.passwordInput).toBeVisible();
    await expect(loginPage.loginButton).toBeVisible();
  })
});
