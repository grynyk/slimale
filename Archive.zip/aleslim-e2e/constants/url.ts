export const QUIZ_URL: string = process.env.QUIZ_URL || '';
export const APP_URL: string = process.env.APP_URL || '';
