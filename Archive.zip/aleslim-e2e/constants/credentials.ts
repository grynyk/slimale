const INVALID_TEST_EMAIL: string = 'test@email';
const INVALID_TEST_PASSWORD: string = 'testpassword';
const VALID_TEST_EMAIL: string = process.env.VALID_TEST_EMAIL || '';
const VALID_TEST_PASSWORD: string = process.env.VALID_TEST_PASSWORD || '';

export const credentials = {
  valid: {
    EMAIL: VALID_TEST_EMAIL,
    PASSWORD: VALID_TEST_PASSWORD
  }, 
  invalid: {
    EMAIL: INVALID_TEST_EMAIL,
    PASSWORD: INVALID_TEST_PASSWORD
  }
};
