async function globalTeardown(): void {
  console.log("Global tear down is running...");
}

export default globalTeardown;