export interface Module1TestData {
    "Skill1": string;
    "Skill2": string;
    "Skill3": string;
    "Skill4": string;
    "Skill5": string;
    "Skill6": string;
    "Skill7": string;
}

export interface TestData {
    Module1TestData?: Module1TestData;
}